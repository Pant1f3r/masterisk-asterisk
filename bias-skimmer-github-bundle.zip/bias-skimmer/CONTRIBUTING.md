# Contributing to Bias Skimmer

Issues, pull requests, and substantive corrections are welcome.

## Reporting Issues

If you've found a bug, please open an issue with:
- Python version and OS
- A minimal reproducible example
- Expected vs. actual behavior

## Pull Requests

Before submitting a PR:

1. **Run the test suite** — `python3 tests/test_bias_skimmer.py` must show 21/21 passing
2. **Add tests** for any new behavior
3. **Keep dependencies minimal** — the core Skimmer should require only pandas and numpy
4. **Match the existing style** — see `bias_skimmer.py` for conventions

## Roadmap

The v1.1 roadmap, documented in Chapter 13.7 of the book, includes:

- Mutual-information and conditional-independence tests in the Trickster Audit
- Bootstrap confidence intervals and significance testing on findings
- Domain-specific Mirror Audit variants (Fitzpatrick, dialect, age)
- Protected-class imputation via Bayesian Improved Surname Geocoding (BISG)

PRs implementing any of these are particularly welcome.

## Reporting Real-World Findings

If you've used the Skimmer in a real production audit that surfaced an actual
disparity (especially one that led to remediation), the author would like to
hear about it. Email **ecc@cyberfaq.net**. Confidentiality respected.

## Code of Conduct

Be respectful. Disagreement on technical merit is fine; personal attacks are not.
